# job.json 与输出契约字段说明

## 一、输入：网页导出的 job.json

网页「点生成」后下载的任务文件。字段：

| 字段 | 含义 |
|---|---|
| `style_id` / `style_name` | 选中的风格技能 id / 名称 |
| `model` | 建议出图模型路由（nano pro / gpt-image-2） |
| `theme` | 主题（如「夏日海岛探宝」） |
| `mascot` | 吉祥物/品牌符号（可空） |
| `ratio` / `size` / `aspect` | 出图比例（默认 9:16 竖屏，成套 UI 用） |
| `hasCharRef` | 是否上传了主角参考图（true → 必须图生图锁角色） |
| `refRoles.color_dna` | ① 配色&品牌DNA 参考：count + use=提取配色系统+品牌DNA |
| `refRoles.graphic` | ② 图形元素参考：count + use=提取造型/装饰母题 |
| `refRoles.play` | ③ 玩法参考：count + use=参考布局/交互/玩法结构 |
| `analysis_todo` | 需要 agent 真产出的三块分析清单 |
| `hero` | 主角出图 prompt |
| `cells[]` | 每个界面格：cell(id) / label / prompt / negative / model / aspect |

> 网页并**不**把上传的参考图二进制塞进 job.json（只带 count）。所以跑之前要向组员要那几张参考图原图，或用网页 outputs 里已有的。

## 二、输出 1：outputs/manifest.json（画布图清单）

```json
{
  "id": "主题-YYYYMMDD",
  "style_id": "street-anime-kawaii",
  "theme": "夏日海岛探宝",
  "ref_hero": "hero.png",
  "cells": {
    "login": "login.png",
    "level": "level.png",
    "battle": "battle.png",
    "result": "result.png",
    "components": "components.png"
  }
}
```
- `cells` 的 key 要与网页 CELLS 的 image 格 id 一致（login/level/battle/result/components）。
- 图片文件与 manifest 放同一 `outputs/` 目录。
- 别把 hero 塞进 cells（它是主角锚点，走 ref_hero）。

## 三、输出 2：outputs/analysis.json（右栏三块真分析）

右栏三块渲染函数期望的结构，字段名错一个 → 该块显示「待生成」占位。

```json
{
  "palette": {
    "source": "取自本批主角 hero.png + 成品场景图，median-cut 真取色",
    "groups": [
      { "type": "主色 · 品牌 DNA（取自主角）",
        "colors": [ { "name": "潮汐天蓝", "hex": "#26A0DC", "use": "主角识别主色 / 主导蓝调" } ] },
      { "type": "点睛色 · 能量光（取自角色荧光装饰）",
        "colors": [ { "name": "荧光电粉", "hex": "#FF5FA2", "use": "点睛/高光/强调" } ] },
      { "type": "辅助色 · 探宝场景",
        "colors": [ { "name": "碧波海青", "hex": "#56DBF0", "use": "场景水域/海岛" } ] },
      { "type": "深色版 · 暗部",
        "colors": [ { "name": "深靛夜", "hex": "#373347", "use": "装备暗部/描边" } ] }
    ]
  },
  "keywords": {
    "refs": [
      { "label": "① 配色&品牌DNA参考（蓝发朋克少女）",
        "features": ["高辨识天蓝长发", "玫紫→荧光粉朋克撞色", "chibi 软萌大眼"],
        "application": "定为品牌主色系与角色识别符号" }
    ],
    "summary": "融合方向：以蓝发+荧光粉的高辨识配色统领全套，海岛探宝提供暖沙金辅助。"
  },
  "worldview": {
    "plans": [
      { "name": "潮汐藏珍 · 逐浪寻宝家",
        "concept": "核心概念一句话",
        "visual": "视觉元素",
        "symbol": "象征意义",
        "slogan": "品牌口号",
        "values": ["价值1", "价值2", "价值3"],
        "recommend": true },
      { "name": "晴岛拾光 · 慢享收集季",
        "concept": "…", "visual": "…", "symbol": "…", "slogan": "…",
        "values": ["…"], "recommend": false }
    ]
  }
}
```

### 硬性约束
- `palette.groups[].colors[]` 每项 = name(品牌化中文名) + hex + use，三者齐。
- `keywords.refs[]` 每项 = label + features[](数组) + application。
- `worldview.plans[]` **至少 2 套**，每套 6 字段（name/concept/visual/symbol/slogan/values[]），**至少一套 recommend:true**。

完整可运行样例见同目录 `example-analysis.json`（金克丝海岛探宝 demo，真取色跑出来的）。
