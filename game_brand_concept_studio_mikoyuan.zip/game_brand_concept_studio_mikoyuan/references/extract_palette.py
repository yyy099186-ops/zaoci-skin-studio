#!/usr/bin/env python3
"""median-cut 真取色：对参考图/成品图提取主色，供品牌色彩系统命名。
用法: python extract_palette.py 图1.png [图2.png ...]
依赖: pillow (pip install pillow)
"""
import sys, colorsys
from PIL import Image


def extract(path, n=12):
    im = Image.open(path).convert('RGB')
    im.thumbnail((240, 240))
    q = im.quantize(colors=n, method=Image.MEDIANCUT).convert('RGB')
    total = im.size[0] * im.size[1]
    cols = q.getcolors(total)
    cols.sort(reverse=True)
    out = []
    for cnt, (r, g, b) in cols:
        if r > 236 and g > 236 and b > 232:
            continue  # 跳过近白背景
        h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
        out.append({
            'hex': '#%02X%02X%02X' % (r, g, b),
            'H': round(h * 360), 'S': round(s * 100), 'L': round(l * 100),
            'ratio': round(cnt / total * 100, 1),
        })
    return out


def main():
    if len(sys.argv) < 2:
        print('用法: python extract_palette.py 图1.png [图2.png ...]')
        return
    for p in sys.argv[1:]:
        print('\n=== %s ===' % p)
        for c in extract(p):
            print('%s  H%3d S%3d L%3d  占比%s%%' % (c['hex'], c['H'], c['S'], c['L'], c['ratio']))


if __name__ == '__main__':
    main()
